﻿using Microsoft.AspNetCore.Mvc;
using PSProject.Data;
using PSProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PSProject.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDBContext _db;

        public BookingController(ApplicationDBContext db)

        {
            _db = db;

        }

        public IActionResult Index()
        {
            IEnumerable<Patient> objList = _db.Patients;
            return View(objList);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();

        }
        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult Create (Patient obj)
        {
            _db.Patients.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");

        }
        public IActionResult ViewBooking()
        {
            var patient = _db.Patients.ToList();
            return View(patient);
        }
       

    }
}
